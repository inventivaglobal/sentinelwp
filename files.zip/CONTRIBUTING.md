# Contributing to SentinelWP

Thank you for helping make WordPress hosting safer.

## How to Contribute

### Report a new malware pattern
Open an issue with:
- The malware signature or filename
- What it does
- How you found it
- Any related files (attack chain)

We'll add detection and auto-response.

### Submit a pull request
1. Fork the repo
2. Create a branch: `git checkout -b feature/new-pattern`
3. Make your changes
4. Test with `bash -n sentinel.sh`
5. Submit a PR with description of what you added

### Attack chain format
In `sentinel.sh`, add to the `ATTACK_CHAINS` array:
```bash
["filename.php"]="threat_type|action|description"
```

Actions available:
- `delete_self` — delete the trigger file
- `delete_parent_dir:path` — delete a directory
- `restore_index` — restore clean index.php
- `restore_htaccess` — restore clean .htaccess
- `remove_cron:user` — remove malicious cron

## Code Style
- Bash 4+ compatible
- Always quote variables
- Add comments for non-obvious logic
- Test with ShellCheck before submitting
