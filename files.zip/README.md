<div align="center">

```
███████╗███████╗███╗   ██╗████████╗██╗███╗   ██╗███████╗██╗    ██╗██████╗
██╔════╝██╔════╝████╗  ██║╚══██╔══╝██║████╗  ██║██╔════╝██║    ██║██╔══██╗
███████╗█████╗  ██╔██╗ ██║   ██║   ██║██╔██╗ ██║█████╗  ██║ █╗ ██║██████╔╝
╚════██║██╔══╝  ██║╚██╗██║   ██║   ██║██║╚██╗██║██╔══╝  ██║███╗██║██╔═══╝
███████║███████╗██║ ╚████║   ██║   ██║██║ ╚████║███████╗╚███╔███╔╝██║
╚══════╝╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝ ╚═╝
```

**WordPress Threat Detection & Auto-Response System**

[![License: MIT](https://img.shields.io/badge/License-MIT-00ff88.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Ubuntu%2022%2B-blue.svg)]()
[![CloudPanel](https://img.shields.io/badge/Panel-CloudPanel%20v2-blue.svg)]()
[![Hostinger](https://img.shields.io/badge/VPS-Hostinger-orange.svg)]()
[![WordPress](https://img.shields.io/badge/WordPress-6%2B%20%7C%207%2B-21759b.svg)]()
[![Status](https://img.shields.io/badge/Status-Active-00ff88.svg)]()

*Born from a real incident. Built to fight back.*

</div>

---

## What is SentinelWP?

SentinelWP is a real-time WordPress threat detection and auto-response system for Linux VPS servers running CloudPanel or similar control panels.

It was built after a sophisticated Chinese backdoor kit compromised 3 sites on a 100+ site Hostinger VPS — silently installing cryptominers, creating 6,800 fake user accounts, and deleting security plugins to avoid detection.

SentinelWP watches every WordPress site on your server simultaneously, recognises known malware patterns and attack chains, and responds automatically — deleting threats, restoring clean files, and alerting you within seconds.

---

## Features

- **Real-time file watching** — monitors all WordPress sites simultaneously using `inotifywait`
- **Attack chain detection** — knows that File A appearing means File B exists somewhere else
- **Auto-response** — deletes threats, restores clean `index.php`/`.htaccess`, removes miner crons
- **Tripwire files** — decoy files at known malware locations that fire webhook alerts on access
- **Causal chain blocking** — immutable decoy files prevent malware from writing to known paths
- **n8n integration** — webhook alerts with full forensic details
- **Slack notifications** — CRITICAL alerts with @channel, standard alerts for HIGH
- **Google Sheets logging** — every incident logged automatically
- **Beautiful dashboard** — dark terminal-style web UI with live incident feed
- **Systemd service** — runs as a persistent background service with auto-restart

---

## Known Attack Patterns

SentinelWP detects and responds to these known attack chains out of the box:

| Trigger File | Attack Type | Auto-Response |
|-------------|-------------|---------------|
| `index.php` > 1kb | Chinese backdoor loader | Restore clean + lock |
| `goto WuWusL0JUctm` signature | Chinese backdoor kit | Delete or restore |
| `wp-admin/user/user/cache.php` | Persistence mechanism | Delete entire directory |
| `wp-admin/user/user/index.php` | Persistence mechanism | Delete entire directory |
| `!clean!time!` | C2 beacon file | Delete immediately |
| `adminfuns.php` | Chinese toolkit | Delete immediately |
| `epinyins.php` | Chinese toolkit | Delete immediately |
| `cjfuns.php` | Chinese toolkit | Delete immediately |
| `comfunctions.php` | Chinese toolkit | Delete immediately |
| `eval(base64_decode` | Obfuscated backdoor | Delete or restore |
| Cron with `#defunct-kernel` | Cryptominer | Remove cron + kill process |
| `.htaccess` with `epinyins` whitelist | Toolkit whitelist | Restore clean .htaccess |
| PHP files in `wp-content/uploads` | Web shell | Delete immediately |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    SentinelWP v1.0                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Layer 1: inotifywait File Watchers                     │
│           Watches /home/*/htdocs/*/ in real-time        │
│                         │                               │
│  Layer 2: Pattern Matcher                               │
│           Checks filenames + signatures + file size     │
│                         │                               │
│  Layer 3: Chain Detector                                │
│           File A found → searches for related File B    │
│                         │                               │
│  Layer 4: Auto-Responder                                │
│           Deletes, restores, locks, kills processes     │
│                         │                               │
│  Layer 5: n8n Webhook                                   │
│           Sends forensic payload to n8n workflow        │
│                         │                               │
│  Layer 6: Alerts + Logging                              │
│           Slack (@channel for CRITICAL) + Google Sheets │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Quick Install

### Prerequisites
- Ubuntu 22.04+ VPS
- Root SSH access
- n8n instance (for webhook alerts)
- Slack workspace (for notifications)

### 1. Set up n8n webhook
Import `n8n-workflow.json` into your n8n instance and get the webhook URL.

### 2. Install SentinelWP

```bash
git clone https://github.com/YOUR_USERNAME/sentinelwp.git
cd sentinelwp
bash install.sh https://your-n8n-instance.com/webhook/sentinelwp-alert
```

That's it. SentinelWP will:
- Install `inotify-tools`
- Register as a systemd service
- Deploy tripwires to all WordPress sites
- Run an initial full scan
- Start watching in real-time

### 3. Verify

```bash
sentinelwp status
tail -f /var/log/sentinelwp.log
```

---

## Dashboard

Open `dashboard.html` in any browser for a live view of:
- Active incidents with severity levels
- Known attack chain diagrams
- Site-by-site health status
- Terminal log feed
- Server health summary

---

## Commands

```bash
sentinelwp install                    # Install as systemd service
sentinelwp start                      # Start watchers (foreground)
sentinelwp scan                       # Scan all sites now
sentinelwp deploy-tripwires [url]     # Deploy tripwires to all sites
sentinelwp stop                       # Stop all watchers
sentinelwp status                     # Show service status
```

---

## Alert Severity Levels

| Level | Trigger | Slack |
|-------|---------|-------|
| `CRITICAL` | Active backdoor, miner, persistence mechanism | @channel mention |
| `HIGH` | Toolkit file, signature match, .htaccess poisoned | Standard alert |
| `MEDIUM` | Tripwire hit, suspicious file, beacon | Standard alert |

---

## Tripwire System

SentinelWP deploys PHP tripwire files at all known malware target locations. When malware tries to access these files:

1. The tripwire fires a webhook immediately
2. You receive an alert with the attacker's IP, user agent, and timestamp
3. The file returns a 404 so the attacker thinks nothing is there
4. The causal chain detector searches for and deletes related malware files

Known malware paths are made immutable using `chattr +i` so malware cannot overwrite the tripwires.

---

## Files

```
sentinelwp/
├── sentinel.sh          # Main monitoring daemon
├── install.sh           # One-command installer
├── dashboard.html       # Web dashboard UI
├── n8n-workflow.json    # n8n alert workflow (import directly)
├── README.md            # This file
└── LICENSE              # MIT License
```

---

## Roadmap

- [ ] Email alerts
- [ ] SMS via Twilio
- [ ] Per-site configuration file
- [ ] Whitelist for legitimate file changes
- [ ] Cloudflare API integration — auto-block attacking IPs
- [ ] Automatic WP admin password rotation on detection
- [ ] Client-facing incident reports
- [ ] Discord webhook support
- [ ] Web dashboard with live WebSocket feed
- [ ] Docker container
- [ ] Plesk + cPanel support

---

## Contributing

Pull requests welcome. Please open an issue first to discuss what you'd like to change.

If you've encountered a new malware pattern not in the attack chain list, please share it — we'll add detection and auto-response for it.

---

## Origin Story

This tool was built during a live incident response on a 100+ site Hostinger VPS that had been compromised by a sophisticated Chinese WordPress backdoor kit. The malware:

- Installed a 21kb backdoor loader in `index.php`
- Set up C2 communication with `zs874v13.phonee.ink`
- Deployed cryptominers on 3 site user accounts
- Created 6,800 fake WordPress customer accounts
- Specifically targeted and deleted Wordfence, Sucuri, and Limit Login Attempts plugins
- Used persistence files in `wp-admin/user/user/` to respawn after cleanup

SentinelWP was built to ensure this never happens silently again.

---

## License

MIT © 2026 [Inventiva Creative Studio](https://inventiva.global)

---

<div align="center">

Built with fury after a long night of malware cleanup.

**If this saved your server, give it a ⭐**

</div>
